INSERT INTO product (sku, name, brand, size, price, imageurl) VALUES ('FAL-8406270', '500 Zapatilla Urbana Muje', 'NEW BALANCE', '37', 42990.00, 'https://falabella.scene7.com/is/image/Falabella/8406270_1');
INSERT INTO product (sku, name, brand, size, price, imageurl) VALUES ('FAL-881952283', 'Bicicleta Baltoro Aro 29', 'JEEP', 'ST', 399990.00, 'https://falabella.scene7.com/is/image/Falabella/8406270_1');
INSERT INTO product (sku, name, brand, size, price, imageurl) VALUES ('FAL-881898502', 'Camisa Manga Corta Hombre', 'BASEMENT', 'M', 24990.00, 'https://falabella.scene7.com/is/image/Falabella/8406270_1');
INSERT INTO product (sku, name, brand, size, price, imageurl) VALUES ('FAL-881898502', 'Camisa Manga Corta Hombre', 'BASEMENT', 'M', 24990.00, 'https://falabella.scene7.com/is/image/Falabella/8406270_1');


INSERT INTO image (id, url, product_id) VALUES (1, 'https://falabella.scene7.com/is/image/Falabella/8406270_1', 1);
INSERT INTO image (id, url, product_id) VALUES (2, 'https://falabella.scene7.com/is/image/Falabella/8406270_1', 1);
INSERT INTO image (id, url, product_id) VALUES (3, 'https://falabella.scene7.com/is/image/Falabella/8406270_1', 2);
INSERT INTO image (id, url, product_id) VALUES (4, 'https://falabella.scene7.com/is/image/Falabella/8406270_1', 3);
INSERT INTO image (id, url, product_id) VALUES (5, 'https://falabella.scene7.com/is/image/Falabella/8406270_1', 3);