package com.falabella.cl.OfflineCodingEvaluation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OfflineCodingEvaluationApplication {

	public static void main(String[] args) {
		SpringApplication.run(OfflineCodingEvaluationApplication.class, args);
	}

}
